# Projet-Android

<h3>Sujet :</h3>
L'entreprise JreleveCompteursDuLimousin est chargée de la relève des compteurs d'eau pour la ville de Limoges.
Afin de faciliter le travail des agents releveurs, la direction a décidé de développer une application pour smartphone.<br/>

<h3>Résumé des objectifs :</h3>
- Réalisez la page de connexion.<br/>
- Afficher les données des compteurs sous forme d'une liste.<br/>
- Afficher les données d'un compteur ainsi que la modification/saisie d'un index.<br/>
- Indiquer par une icone les relevés faits et ceux à faire.<br/>
- Permettre le filtre des compteur en fonction de leur statut.<br/>
- Prévoir une rubrique maintenance pour chaque compteur.<br/>
- Ajouter un champs téléphone dans chaque compteur.<br/>
