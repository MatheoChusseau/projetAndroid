package fr.gds.relevecompteur;

public class Compteur {

    public int id;
    public String nom;
    public String rue;
    public String codePostal;
    public String ville;
    public int indexAncien;
    public int indexNouveau;
    public String nomReleveur;
    public String numTelephone;
}