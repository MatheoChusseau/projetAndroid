package fr.gds.relevecompteur;

import android.graphics.Bitmap;

import java.sql.Blob;

public class Releveur {
    public int id;
    public String nomReleveur;
    public String motDePasse;
    public Bitmap image;
}